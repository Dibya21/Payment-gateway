var PaytmConfig = {
	mid: "DOWwQb49205273184617",
	key: "fy!FIU2rqw9WfW1A",
	website: "WEBSTAGING",
  };
  module.exports.PaytmConfig = PaytmConfig;