# Payment-Gateway-Integration

This is a simple website in which payment gateway integration is done using Paytm
